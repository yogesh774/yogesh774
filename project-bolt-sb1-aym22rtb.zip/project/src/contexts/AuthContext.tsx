import React, { createContext, useState, useContext, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import type { User } from '@supabase/supabase-js';

interface AuthUser {
  id: string;
  name: string;
  email: string;
  role: 'student' | 'admin' | 'security';
  studentId?: string;
  department?: string;
  image?: string;
}

interface AuthContextType {
  currentUser: AuthUser | null;
  login: (email: string, password: string, name?: string) => Promise<boolean>;
  logout: () => void;
  isAuthenticated: boolean;
}

const AuthContext = createContext<AuthContextType>({
  currentUser: null,
  login: async () => false,
  logout: () => {},
  isAuthenticated: false
});

export const useAuth = () => useContext(AuthContext);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentUser, setCurrentUser] = useState<AuthUser | null>(null);
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(false);

  useEffect(() => {
    // Check active session
    supabase.auth.getSession().then(({ data: { session } }) => {
      if (session?.user) {
        fetchUserData(session.user);
      }
    });

    // Listen for auth changes
    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
      if (session?.user) {
        fetchUserData(session.user);
      } else {
        setCurrentUser(null);
        setIsAuthenticated(false);
      }
    });

    return () => {
      subscription.unsubscribe();
    };
  }, []);

  const fetchUserData = async (user: User) => {
    const { data, error } = await supabase
      .from('users')
      .select('*')
      .eq('id', user.id)
      .single();

    if (error) {
      console.error('Error fetching user data:', error);
      return;
    }

    if (data) {
      setCurrentUser({
        id: data.id,
        name: data.name,
        email: data.email,
        role: data.role,
        studentId: data.student_id,
        department: data.department
      });
      setIsAuthenticated(true);
    }
  };

  const login = async (email: string, password: string, name?: string): Promise<boolean> => {
    try {
      const { data: { user }, error: signInError } = await supabase.auth.signInWithPassword({
        email,
        password
      });

      if (signInError || !user) {
        // If login fails, try to sign up if name is provided
        if (name) {
          const { data: { user: newUser }, error: signUpError } = await supabase.auth.signUp({
            email,
            password
          });

          if (signUpError || !newUser) {
            console.error('Sign up error:', signUpError);
            return false;
          }

          // Insert user data into users table
          const { error: insertError } = await supabase
            .from('users')
            .insert([
              {
                id: newUser.id,
                email,
                name,
                role: email.includes('admin') ? 'admin' : 
                      email.includes('security') ? 'security' : 'student',
                department: email.includes('student') ? 'Computer Science' : null,
                student_id: email.includes('student') ? `S${Math.random().toString().slice(2, 7)}` : null
              }
            ]);

          if (insertError) {
            console.error('Error creating user profile:', insertError);
            return false;
          }
        } else {
          console.error('Sign in error:', signInError);
          return false;
        }
      }

      return true;
    } catch (error) {
      console.error('Login error:', error);
      return false;
    }
  };

  const logout = async () => {
    await supabase.auth.signOut();
    setCurrentUser(null);
    setIsAuthenticated(false);
  };

  return (
    <AuthContext.Provider value={{
      currentUser,
      login,
      logout,
      isAuthenticated
    }}>
      {children}
    </AuthContext.Provider>
  );
};