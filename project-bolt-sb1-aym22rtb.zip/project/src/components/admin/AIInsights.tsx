import React from 'react';
import { BarChart3, PieChart, LineChart, Users, TrendingUp, AlertTriangle } from 'lucide-react';

const AIInsights: React.FC = () => {
  // In a real app, this data would come from an AI analysis module
  const flaggedStudents = [
    { id: '1', name: 'John Doe', department: 'Computer Science', pattern: 'Frequent late returns', riskLevel: 'high' },
    { id: '2', name: 'Emma Wilson', department: 'Business', pattern: 'Multiple passes in short period', riskLevel: 'medium' },
    { id: '3', name: 'Michael Brown', department: 'Engineering', pattern: 'Pattern of weekend absences', riskLevel: 'low' }
  ];

  return (
    <div className="p-6">
      <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-6">
        <div>
          <h2 className="text-xl font-semibold text-gray-800">AI Behavior Insights</h2>
          <p className="text-gray-600">Pattern analysis and anomaly detection</p>
        </div>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
        <div className="bg-indigo-50 rounded-lg p-4 border border-indigo-100">
          <div className="flex items-center mb-3">
            <BarChart3 className="h-5 w-5 text-indigo-600 mr-2" />
            <h3 className="text-md font-medium text-indigo-900">Usage Patterns</h3>
          </div>
          <p className="text-sm text-indigo-800">
            AI has analyzed 230 gate passes over the last 30 days and identified 12 suspicious patterns.
          </p>
        </div>
        
        <div className="bg-emerald-50 rounded-lg p-4 border border-emerald-100">
          <div className="flex items-center mb-3">
            <TrendingUp className="h-5 w-5 text-emerald-600 mr-2" />
            <h3 className="text-md font-medium text-emerald-900">Predictive Insights</h3>
          </div>
          <p className="text-sm text-emerald-800">
            Expected 15% increase in gate pass requests during upcoming examination period.
          </p>
        </div>
        
        <div className="bg-amber-50 rounded-lg p-4 border border-amber-100">
          <div className="flex items-center mb-3">
            <AlertTriangle className="h-5 w-5 text-amber-600 mr-2" />
            <h3 className="text-md font-medium text-amber-900">Security Alerts</h3>
          </div>
          <p className="text-sm text-amber-800">
            3 students flagged for potential policy violations based on movement patterns.
          </p>
        </div>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
        <div className="bg-white rounded-lg shadow p-4">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-medium text-gray-900">Weekly Gate Usage</h3>
            <LineChart className="h-5 w-5 text-gray-400" />
          </div>
          <div className="h-64 bg-gray-50 rounded border border-gray-200 flex items-center justify-center">
            {/* This would be a real chart in a production app */}
            <div className="text-center p-4">
              <LineChart className="mx-auto h-8 w-8 text-gray-300" />
              <p className="mt-2 text-sm text-gray-500">Weekly gate usage trend visualization</p>
              <p className="text-xs text-gray-400 mt-1">Peak usage detected on Fridays and weekends</p>
            </div>
          </div>
        </div>
        
        <div className="bg-white rounded-lg shadow p-4">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-medium text-gray-900">Request Distribution</h3>
            <PieChart className="h-5 w-5 text-gray-400" />
          </div>
          <div className="h-64 bg-gray-50 rounded border border-gray-200 flex items-center justify-center">
            {/* This would be a real chart in a production app */}
            <div className="text-center p-4">
              <PieChart className="mx-auto h-8 w-8 text-gray-300" />
              <p className="mt-2 text-sm text-gray-500">Pass request reasons distribution</p>
              <p className="text-xs text-gray-400 mt-1">Family visits (40%), Personal errands (30%), Medical (15%), Other (15%)</p>
            </div>
          </div>
        </div>
      </div>
      
      <div className="bg-white rounded-lg shadow overflow-hidden mb-6">
        <div className="px-4 py-5 border-b border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-lg font-medium text-gray-900">Students with Flagged Behavior</h3>
              <p className="text-sm text-gray-500">AI-detected unusual patterns</p>
            </div>
            <Users className="h-5 w-5 text-gray-400" />
          </div>
        </div>
        
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Student
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Department
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Detected Pattern
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Risk Level
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Action
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {flaggedStudents.map((student) => (
                <tr key={student.id}>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm font-medium text-gray-900">{student.name}</div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm text-gray-500">{student.department}</div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm text-gray-900">{student.pattern}</div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full 
                      ${student.riskLevel === 'high' ? 'bg-red-100 text-red-800' : 
                        student.riskLevel === 'medium' ? 'bg-amber-100 text-amber-800' : 
                        'bg-blue-100 text-blue-800'}`}
                    >
                      {student.riskLevel.charAt(0).toUpperCase() + student.riskLevel.slice(1)}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    <button className="text-blue-600 hover:text-blue-900">
                      Review
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
      
      <div className="bg-blue-50 border-l-4 border-blue-400 p-4 rounded-md">
        <div className="flex">
          <div className="flex-shrink-0">
            <AlertTriangle className="h-5 w-5 text-blue-500" />
          </div>
          <div className="ml-3">
            <h3 className="text-sm font-medium text-blue-800">AI Insights Information</h3>
            <p className="text-sm text-blue-700 mt-1">
              The AI module analyzes student movement patterns to identify potential security concerns or policy violations.
              These insights are for administrative review only and should be verified before taking action.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AIInsights;