import React, { useState } from 'react';
import { useNotification } from '../../contexts/NotificationContext';
import { 
  AlertTriangle, 
  Check, 
  X, 
  Calendar, 
  Clock, 
  MapPin, 
  User,
  Search
} from 'lucide-react';
import { mockGatePasses, mockStudents } from '../../data/mockData';

interface GatePass {
  id: string;
  studentId: string;
  reason: string;
  destination: string;
  leaveDate: string;
  leaveTime: string;
  expectedReturnDate: string;
  expectedReturnTime: string;
  status: 'pending' | 'approved' | 'rejected';
  aiFlag?: boolean;
  aiReason?: string;
}

const PendingRequests: React.FC = () => {
  const { addNotification } = useNotification();
  const [searchTerm, setSearchTerm] = useState('');
  
  // Get pending requests
  const pendingRequests = mockGatePasses.filter(pass => pass.status === 'pending');
  
  // Filter by search term
  const filteredRequests = pendingRequests.filter(pass => {
    const student = mockStudents.find(s => s.id === pass.studentId);
    return (
      student?.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      pass.destination.toLowerCase().includes(searchTerm.toLowerCase()) ||
      pass.reason.toLowerCase().includes(searchTerm.toLowerCase())
    );
  });

  const handleApprove = (passId: string) => {
    addNotification('Gate pass approved successfully', 'success');
    // In a real app, this would call an API to update the pass status
  };

  const handleReject = (passId: string) => {
    addNotification('Gate pass rejected', 'info');
    // In a real app, this would call an API to update the pass status
  };

  const getStudentName = (studentId: string) => {
    const student = mockStudents.find(s => s.id === studentId);
    return student ? student.name : 'Unknown Student';
  };

  return (
    <div className="overflow-x-auto">
      <div className="p-4 border-b border-gray-200">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center">
          <h2 className="text-xl font-semibold text-gray-800 mb-4 md:mb-0">Pending Gate Pass Requests</h2>
          
          <div className="relative w-full md:w-64">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <Search className="h-5 w-5 text-gray-400" />
            </div>
            <input
              type="text"
              placeholder="Search requests..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500 text-sm"
            />
          </div>
        </div>
      </div>
      
      {filteredRequests.length === 0 ? (
        <div className="text-center py-12">
          <Clock className="mx-auto h-12 w-12 text-gray-400" />
          <h3 className="mt-2 text-lg font-medium text-gray-900">No pending requests</h3>
          <p className="mt-1 text-sm text-gray-500">All gate pass requests have been processed.</p>
        </div>
      ) : (
        <div className="divide-y divide-gray-200">
          {filteredRequests.map((request) => {
            const student = mockStudents.find(s => s.id === request.studentId);
            
            return (
              <div key={request.id} className={`p-6 ${request.aiFlag ? 'bg-red-50' : ''}`}>
                <div className="flex flex-col md:flex-row md:items-center md:justify-between">
                  <div className="flex-1">
                    <div className="flex items-start">
                      <div className="flex-shrink-0">
                        <div className="w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center">
                          {student?.image ? (
                            <img 
                              src={student.image} 
                              alt={student.name} 
                              className="w-10 h-10 rounded-full object-cover"
                            />
                          ) : (
                            <User className="h-5 w-5 text-blue-700" />
                          )}
                        </div>
                      </div>
                      <div className="ml-4">
                        <div className="flex items-center">
                          <h3 className="text-lg font-medium text-gray-900">{getStudentName(request.studentId)}</h3>
                          {request.aiFlag && (
                            <div className="ml-2 flex items-center text-red-600 bg-red-100 px-2 py-0.5 rounded-full text-xs">
                              <AlertTriangle className="h-3 w-3 mr-1" />
                              Flagged by AI
                            </div>
                          )}
                        </div>
                        <p className="text-gray-600">{student?.department || 'Unknown Department'}</p>
                        
                        <div className="mt-3">
                          <h4 className="text-sm font-medium text-gray-900">Reason for Gate Pass:</h4>
                          <p className="text-gray-600 mt-1">{request.reason}</p>
                        </div>
                        
                        <div className="mt-4 grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div className="flex items-center text-gray-600">
                            <MapPin className="h-4 w-4 text-gray-500 mr-1" />
                            <span>Destination: {request.destination}</span>
                          </div>
                          <div className="flex items-center text-gray-600">
                            <Calendar className="h-4 w-4 text-gray-500 mr-1" />
                            <span>Leave: {new Date(request.leaveDate).toLocaleDateString()} at {request.leaveTime}</span>
                          </div>
                          <div className="flex items-center text-gray-600">
                            <Clock className="h-4 w-4 text-gray-500 mr-1" />
                            <span>Return by: {new Date(request.expectedReturnDate).toLocaleDateString()} at {request.expectedReturnTime}</span>
                          </div>
                        </div>
                        
                        {request.aiFlag && request.aiReason && (
                          <div className="mt-4 bg-red-100 border-l-4 border-red-500 p-4 rounded">
                            <div className="flex">
                              <div className="flex-shrink-0">
                                <AlertTriangle className="h-5 w-5 text-red-600" />
                              </div>
                              <div className="ml-3">
                                <h3 className="text-sm font-medium text-red-800">AI Flag Reason:</h3>
                                <p className="text-sm text-red-700 mt-1">{request.aiReason}</p>
                              </div>
                            </div>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                  
                  <div className="mt-6 md:mt-0 flex space-x-3">
                    <button
                      onClick={() => handleApprove(request.id)}
                      className="inline-flex items-center px-4 py-2 bg-green-600 hover:bg-green-700 text-white text-sm font-medium rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500 transition-colors"
                    >
                      <Check className="h-4 w-4 mr-1" />
                      Approve
                    </button>
                    <button
                      onClick={() => handleReject(request.id)}
                      className="inline-flex items-center px-4 py-2 bg-red-600 hover:bg-red-700 text-white text-sm font-medium rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500 transition-colors"
                    >
                      <X className="h-4 w-4 mr-1" />
                      Reject
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};

export default PendingRequests;