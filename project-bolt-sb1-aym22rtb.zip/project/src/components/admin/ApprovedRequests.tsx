import React, { useState } from 'react';
import { Search, User, Calendar, Clock, MapPin, Filter } from 'lucide-react';
import { mockGatePasses, mockStudents } from '../../data/mockData';

const ApprovedRequests: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'active' | 'completed'>('all');
  
  // Get approved requests
  const approvedRequests = mockGatePasses.filter(pass => pass.status === 'approved');
  
  // Apply filters
  const filteredRequests = approvedRequests.filter(pass => {
    const student = mockStudents.find(s => s.id === pass.studentId);
    const matchesSearch = 
      student?.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      pass.destination.toLowerCase().includes(searchTerm.toLowerCase()) ||
      pass.reason.toLowerCase().includes(searchTerm.toLowerCase());
      
    if (statusFilter === 'all') return matchesSearch;
    if (statusFilter === 'active') return matchesSearch && !pass.actualReturnTime;
    if (statusFilter === 'completed') return matchesSearch && !!pass.actualReturnTime;
    
    return matchesSearch;
  });

  const getStudentName = (studentId: string) => {
    const student = mockStudents.find(s => s.id === studentId);
    return student ? student.name : 'Unknown Student';
  };

  return (
    <div className="overflow-x-auto">
      <div className="p-4 border-b border-gray-200">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-4">
          <h2 className="text-xl font-semibold text-gray-800 mb-4 md:mb-0">Approved Gate Passes</h2>
          
          <div className="flex flex-col sm:flex-row gap-4 w-full md:w-auto">
            <div className="relative w-full sm:w-64">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <Search className="h-5 w-5 text-gray-400" />
              </div>
              <input
                type="text"
                placeholder="Search passes..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500 text-sm"
              />
            </div>
            
            <div className="relative w-full sm:w-48">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <Filter className="h-5 w-5 text-gray-400" />
              </div>
              <select
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value as 'all' | 'active' | 'completed')}
                className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500 text-sm appearance-none"
              >
                <option value="all">All Passes</option>
                <option value="active">Active Only</option>
                <option value="completed">Completed</option>
              </select>
            </div>
          </div>
        </div>
      </div>
      
      {filteredRequests.length === 0 ? (
        <div className="text-center py-12">
          <Calendar className="mx-auto h-12 w-12 text-gray-400" />
          <h3 className="mt-2 text-lg font-medium text-gray-900">No approved passes found</h3>
          <p className="mt-1 text-sm text-gray-500">Try changing your filters or search term.</p>
        </div>
      ) : (
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Student
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Destination
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Time Period
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Actual Times
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Status
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {filteredRequests.map((pass) => {
                const student = mockStudents.find(s => s.id === pass.studentId);
                const isActive = !pass.actualReturnTime;
                
                return (
                  <tr key={pass.id} className={isActive ? 'bg-blue-50' : ''}>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center">
                        <div className="flex-shrink-0 h-10 w-10 rounded-full bg-blue-100 flex items-center justify-center overflow-hidden">
                          {student?.image ? (
                            <img 
                              src={student.image} 
                              alt={student.name} 
                              className="h-10 w-10 rounded-full object-cover"
                            />
                          ) : (
                            <User className="h-5 w-5 text-blue-700" />
                          )}
                        </div>
                        <div className="ml-4">
                          <div className="text-sm font-medium text-gray-900">{getStudentName(pass.studentId)}</div>
                          <div className="text-sm text-gray-500">{student?.department || 'Unknown'}</div>
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center">
                        <MapPin className="h-4 w-4 text-gray-500 mr-1" />
                        <span className="text-sm text-gray-900">{pass.destination}</span>
                      </div>
                      <div className="text-sm text-gray-500 mt-1 line-clamp-1">{pass.reason}</div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center text-sm text-gray-900">
                        <Calendar className="h-4 w-4 text-gray-500 mr-1" />
                        <span>{new Date(pass.leaveDate).toLocaleDateString()}</span>
                      </div>
                      <div className="flex items-center text-sm text-gray-500 mt-1">
                        <Clock className="h-4 w-4 text-gray-500 mr-1" />
                        <span>{pass.leaveTime} - {pass.expectedReturnTime}</span>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      {pass.actualExitTime ? (
                        <div>
                          <div className="text-sm text-gray-900">Exit: {pass.actualExitTime}</div>
                          {pass.actualReturnTime ? (
                            <div className="text-sm text-gray-900 mt-1">Return: {pass.actualReturnTime}</div>
                          ) : (
                            <div className="text-sm text-gray-500 mt-1">Not returned yet</div>
                          )}
                        </div>
                      ) : (
                        <span className="text-sm text-gray-500">Not used yet</span>
                      )}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      {!pass.actualExitTime ? (
                        <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-gray-100 text-gray-800">
                          Not Used
                        </span>
                      ) : !pass.actualReturnTime ? (
                        <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-blue-100 text-blue-800">
                          Out of Campus
                        </span>
                      ) : (
                        <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800">
                          Completed
                        </span>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};

export default ApprovedRequests;