import React, { useState } from 'react';
import { useAuth } from '../../contexts/AuthContext';
import { useNotification } from '../../contexts/NotificationContext';
import { Calendar, Clock, MapPin, AlertCircle } from 'lucide-react';

interface FormData {
  reason: string;
  destination: string;
  leaveDate: string;
  leaveTime: string;
  expectedReturnDate: string;
  expectedReturnTime: string;
  contactNumber: string;
  accompaniedBy: string;
}

const GatePassForm: React.FC = () => {
  const { currentUser } = useAuth();
  const { addNotification } = useNotification();
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  const [formData, setFormData] = useState<FormData>({
    reason: '',
    destination: '',
    leaveDate: new Date().toISOString().split('T')[0],
    leaveTime: '',
    expectedReturnDate: new Date().toISOString().split('T')[0],
    expectedReturnTime: '',
    contactNumber: '',
    accompaniedBy: ''
  });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // Validate form
    if (!formData.reason || !formData.destination || !formData.leaveTime || !formData.expectedReturnTime) {
      addNotification('Please fill in all required fields', 'error');
      return;
    }
    
    setIsSubmitting(true);
    
    // Simulate API call
    try {
      // In a real app, this would be an API call to save the gate pass
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      addNotification('Gate pass request submitted successfully!', 'success');
      
      // Reset form
      setFormData({
        reason: '',
        destination: '',
        leaveDate: new Date().toISOString().split('T')[0],
        leaveTime: '',
        expectedReturnDate: new Date().toISOString().split('T')[0],
        expectedReturnTime: '',
        contactNumber: '',
        accompaniedBy: ''
      });
    } catch (error) {
      addNotification('Failed to submit gate pass request', 'error');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div>
      <h2 className="text-xl font-semibold text-gray-800 mb-6">Apply for Gate Pass</h2>
      
      <div className="bg-blue-50 border-l-4 border-blue-400 p-4 mb-6 rounded-md">
        <div className="flex">
          <div className="flex-shrink-0">
            <AlertCircle className="h-5 w-5 text-blue-500" />
          </div>
          <div className="ml-3">
            <p className="text-sm text-blue-700">
              Fill out this form to request permission to leave campus. 
              Your request will be reviewed by faculty and you'll be notified upon approval.
            </p>
          </div>
        </div>
      </div>
      
      <form onSubmit={handleSubmit} className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Student Info - Read only */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Student Name</label>
            <input
              type="text"
              value={currentUser?.name || ''}
              readOnly
              className="bg-gray-100 w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none"
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Student ID</label>
            <input
              type="text"
              value={currentUser?.studentId || ''}
              readOnly
              className="bg-gray-100 w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none"
            />
          </div>
          
          {/* Form Fields */}
          <div className="md:col-span-2">
            <label htmlFor="reason" className="block text-sm font-medium text-gray-700 mb-1">
              Reason for leaving <span className="text-red-500">*</span>
            </label>
            <textarea
              id="reason"
              name="reason"
              rows={3}
              value={formData.reason}
              onChange={handleChange}
              required
              className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-blue-500 focus:border-blue-500"
              placeholder="Please provide a detailed reason for your gate pass request"
            />
          </div>
          
          <div>
            <label htmlFor="destination" className="block text-sm font-medium text-gray-700 mb-1">
              Destination <span className="text-red-500">*</span>
            </label>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <MapPin className="h-5 w-5 text-gray-400" />
              </div>
              <input
                type="text"
                id="destination"
                name="destination"
                value={formData.destination}
                onChange={handleChange}
                required
                className="w-full pl-10 px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                placeholder="Where are you going?"
              />
            </div>
          </div>
          
          <div>
            <label htmlFor="contactNumber" className="block text-sm font-medium text-gray-700 mb-1">
              Contact Number
            </label>
            <input
              type="tel"
              id="contactNumber"
              name="contactNumber"
              value={formData.contactNumber}
              onChange={handleChange}
              className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-blue-500 focus:border-blue-500"
              placeholder="Your phone number while outside"
            />
          </div>
          
          <div>
            <label htmlFor="leaveDate" className="block text-sm font-medium text-gray-700 mb-1">
              Leave Date <span className="text-red-500">*</span>
            </label>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <Calendar className="h-5 w-5 text-gray-400" />
              </div>
              <input
                type="date"
                id="leaveDate"
                name="leaveDate"
                value={formData.leaveDate}
                onChange={handleChange}
                required
                className="w-full pl-10 px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
              />
            </div>
          </div>
          
          <div>
            <label htmlFor="leaveTime" className="block text-sm font-medium text-gray-700 mb-1">
              Leave Time <span className="text-red-500">*</span>
            </label>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <Clock className="h-5 w-5 text-gray-400" />
              </div>
              <input
                type="time"
                id="leaveTime"
                name="leaveTime"
                value={formData.leaveTime}
                onChange={handleChange}
                required
                className="w-full pl-10 px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
              />
            </div>
          </div>
          
          <div>
            <label htmlFor="expectedReturnDate" className="block text-sm font-medium text-gray-700 mb-1">
              Expected Return Date <span className="text-red-500">*</span>
            </label>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <Calendar className="h-5 w-5 text-gray-400" />
              </div>
              <input
                type="date"
                id="expectedReturnDate"
                name="expectedReturnDate"
                value={formData.expectedReturnDate}
                onChange={handleChange}
                required
                className="w-full pl-10 px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
              />
            </div>
          </div>
          
          <div>
            <label htmlFor="expectedReturnTime" className="block text-sm font-medium text-gray-700 mb-1">
              Expected Return Time <span className="text-red-500">*</span>
            </label>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <Clock className="h-5 w-5 text-gray-400" />
              </div>
              <input
                type="time"
                id="expectedReturnTime"
                name="expectedReturnTime"
                value={formData.expectedReturnTime}
                onChange={handleChange}
                required
                className="w-full pl-10 px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
              />
            </div>
          </div>
          
          <div>
            <label htmlFor="accompaniedBy" className="block text-sm font-medium text-gray-700 mb-1">
              Accompanied By
            </label>
            <input
              type="text"
              id="accompaniedBy"
              name="accompaniedBy"
              value={formData.accompaniedBy}
              onChange={handleChange}
              className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-blue-500 focus:border-blue-500"
              placeholder="If applicable"
            />
          </div>
        </div>
        
        <div className="flex justify-end">
          <button
            type="submit"
            disabled={isSubmitting}
            className="bg-blue-800 hover:bg-blue-700 text-white font-medium py-2 px-6 rounded-md shadow-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 transition-colors disabled:opacity-70"
          >
            {isSubmitting ? 'Submitting...' : 'Submit Request'}
          </button>
        </div>
      </form>
    </div>
  );
};

export default GatePassForm;