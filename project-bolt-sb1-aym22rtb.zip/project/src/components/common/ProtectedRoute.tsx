import React from 'react';
import { Navigate } from 'react-router-dom';
import { useAuth } from '../../contexts/AuthContext';

interface ProtectedRouteProps {
  children: React.ReactNode;
  role: 'student' | 'admin' | 'security';
}

const ProtectedRoute: React.FC<ProtectedRouteProps> = ({ children, role }) => {
  const { isAuthenticated, currentUser } = useAuth();

  if (!isAuthenticated) {
    return <Navigate to="/login" replace />;
  }

  // Check if user has the required role
  if (currentUser?.role !== role) {
    // Redirect to appropriate dashboard based on role
    if (currentUser?.role === 'student') {
      return <Navigate to="/student" replace />;
    } else if (currentUser?.role === 'admin') {
      return <Navigate to="/admin" replace />;
    } else if (currentUser?.role === 'security') {
      return <Navigate to="/security" replace />;
    }
  }

  return <>{children}</>;
};

export default ProtectedRoute;