import React from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../../contexts/AuthContext';
import { QrCode, LogOut, Menu, X } from 'lucide-react';

const Header: React.FC = () => {
  const { currentUser, logout } = useAuth();
  const navigate = useNavigate();
  const [mobileMenuOpen, setMobileMenuOpen] = React.useState(false);

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  return (
    <header className="bg-gradient-to-r from-blue-900 to-blue-800 text-white shadow-md">
      <div className="container mx-auto px-4 py-4">
        <div className="flex justify-between items-center">
          <div className="flex items-center space-x-2">
            <QrCode size={28} className="text-amber-400" />
            <h1 className="text-xl font-bold">GateSmart+</h1>
          </div>
          
          {/* Desktop menu */}
          <div className="hidden md:flex items-center space-x-6">
            {currentUser && (
              <>
                <div className="flex items-center space-x-2">
                  <div className="w-8 h-8 rounded-full bg-blue-700 flex items-center justify-center overflow-hidden">
                    {currentUser.image ? (
                      <img src={currentUser.image} alt={currentUser.name} className="w-full h-full object-cover" />
                    ) : (
                      <span className="text-white font-medium">{currentUser.name.charAt(0)}</span>
                    )}
                  </div>
                  <span>{currentUser.name}</span>
                </div>
                <button 
                  onClick={handleLogout}
                  className="flex items-center space-x-1 text-white hover:text-amber-300 transition"
                >
                  <LogOut size={18} />
                  <span>Logout</span>
                </button>
              </>
            )}
          </div>
          
          {/* Mobile menu button */}
          <button 
            className="md:hidden text-white"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          >
            {mobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>
        
        {/* Mobile menu */}
        {mobileMenuOpen && (
          <div className="md:hidden mt-4 space-y-4 py-2 border-t border-blue-700">
            {currentUser && (
              <>
                <div className="flex items-center space-x-2 py-2">
                  <div className="w-8 h-8 rounded-full bg-blue-700 flex items-center justify-center overflow-hidden">
                    {currentUser.image ? (
                      <img src={currentUser.image} alt={currentUser.name} className="w-full h-full object-cover" />
                    ) : (
                      <span className="text-white font-medium">{currentUser.name.charAt(0)}</span>
                    )}
                  </div>
                  <span>{currentUser.name}</span>
                </div>
                <button 
                  onClick={handleLogout}
                  className="flex items-center space-x-1 text-white hover:text-amber-300 transition py-2"
                >
                  <LogOut size={18} />
                  <span>Logout</span>
                </button>
              </>
            )}
          </div>
        )}
      </div>
    </header>
  );
};

export default Header;