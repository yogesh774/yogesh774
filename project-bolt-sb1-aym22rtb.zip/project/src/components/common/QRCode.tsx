import React from 'react';

interface QRCodeProps {
  data: string;
  size?: number;
}

const QRCode: React.FC<QRCodeProps> = ({ data, size = 200 }) => {
  // In a real application, we would use a QR code library
  // For this demo, we'll just create a placeholder
  return (
    <div 
      style={{ 
        width: `${size}px`, 
        height: `${size}px`,
        position: 'relative',
        backgroundColor: '#f3f4f6',
        padding: '20px',
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
        borderRadius: '8px'
      }}
    >
      <div 
        style={{ 
          width: '80%', 
          height: '80%',
          border: '2px solid #1E3A8A',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          backgroundImage: 'url("https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=' + encodeURIComponent(data) + '")',
          backgroundSize: 'contain',
          backgroundPosition: 'center',
          backgroundRepeat: 'no-repeat'
        }}
      />
      <div style={{ fontSize: '12px', marginTop: '10px', color: '#6b7280' }}>
        Pass ID: {data.substring(0, 8)}
      </div>
    </div>
  );
};

export default QRCode;