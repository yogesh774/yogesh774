import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { useNotification } from '../contexts/NotificationContext';
import { QrCode, School, Key, User, Mail, Lock } from 'lucide-react';

const LoginPage: React.FC = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const { login, isAuthenticated, currentUser } = useAuth();
  const { addNotification } = useNotification();
  const navigate = useNavigate();
  const [showNameInput, setShowNameInput] = useState(false);

  useEffect(() => {
    if (isAuthenticated && currentUser) {
      switch (currentUser.role) {
        case 'student':
          navigate('/student');
          break;
        case 'admin':
          navigate('/admin');
          break;
        case 'security':
          navigate('/security');
          break;
      }
    }
  }, [isAuthenticated, currentUser, navigate]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!email || !password) {
      addNotification('Please enter both email and password', 'error');
      return;
    }

    if (showNameInput && !name.trim()) {
      addNotification('Please enter your name', 'error');
      return;
    }

    setIsLoading(true);
    try {
      const success = await login(email, password, name);
      if (success) {
        addNotification('Login successful', 'success');
      } else {
        addNotification('Invalid credentials. Use demo accounts shown on the left.', 'error');
      }
    } catch (error) {
      addNotification('An error occurred during login', 'error');
    } finally {
      setIsLoading(false);
    }
  };

  const demoCredentials = [
    { role: 'Student', email: 'student@example.com', password: 'password' },
    { role: 'Admin/Warden', email: 'admin@example.com', password: 'password' },
    { role: 'Security', email: 'security@example.com', password: 'password' }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-50 to-gray-100 flex flex-col">
      <div className="flex-1 flex flex-col md:flex-row">
        {/* Left side - Banner */}
        <div className="md:w-1/2 bg-gradient-to-br from-blue-900 to-blue-800 text-white p-8 flex flex-col justify-center">
          <div className="max-w-md mx-auto">
            <div className="flex items-center mb-8">
              <QrCode size={40} className="text-amber-400 mr-3" />
              <h1 className="text-3xl font-bold">GateSmart+</h1>
            </div>
            <h2 className="text-2xl font-semibold mb-4">Smart Campus Gate Management System</h2>
            <p className="mb-6 text-blue-100">
              Secure and efficient campus entry/exit management with AI-powered monitoring and real-time notifications.
            </p>
            <div className="bg-blue-800/50 p-4 rounded-lg border border-blue-700">
              <h3 className="font-medium text-amber-300 mb-2">Demo Accounts (Click to try)</h3>
              <div className="space-y-2 text-sm">
                {demoCredentials.map((cred, index) => (
                  <div 
                    key={index} 
                    className="p-2 bg-blue-950/30 rounded cursor-pointer hover:bg-blue-950/50 transition-colors"
                    onClick={() => {
                      setEmail(cred.email);
                      setPassword(cred.password);
                      setShowNameInput(true);
                    }}
                  >
                    <div className="font-medium text-amber-200">{cred.role}</div>
                    <div className="text-blue-200">Email: {cred.email}</div>
                    <div className="text-blue-200">Password: {cred.password}</div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Right side - Login Form */}
        <div className="md:w-1/2 p-8 flex items-center justify-center">
          <div className="bg-white p-8 rounded-lg shadow-lg w-full max-w-md">
            <div className="text-center mb-8">
              <School className="mx-auto h-12 w-12 text-blue-800" />
              <h2 className="mt-4 text-2xl font-bold text-gray-900">Sign in to your account</h2>
              <p className="mt-2 text-gray-600">
                Enter your credentials to access the GateSmart+ system
              </p>
            </div>

            <form onSubmit={handleSubmit} className="space-y-6">
              {showNameInput && (
                <div className="space-y-1">
                  <label htmlFor="name" className="block text-sm font-medium text-gray-700">
                    Your Name
                  </label>
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                      <User className="h-5 w-5 text-gray-400" />
                    </div>
                    <input
                      id="name"
                      type="text"
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      className="pl-10 block w-full rounded-md border border-gray-300 shadow-sm py-2 px-3 focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                      placeholder="Enter your name"
                    />
                  </div>
                </div>
              )}

              <div className="space-y-1">
                <label htmlFor="email" className="block text-sm font-medium text-gray-700">
                  Email address
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <Mail className="h-5 w-5 text-gray-400" />
                  </div>
                  <input
                    id="email"
                    type="email"
                    value={email}
                    onChange={(e) => {
                      setEmail(e.target.value);
                      setShowNameInput(true);
                    }}
                    className="pl-10 block w-full rounded-md border border-gray-300 shadow-sm py-2 px-3 focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                    placeholder="Enter your email"
                  />
                </div>
              </div>

              <div className="space-y-1">
                <label htmlFor="password" className="block text-sm font-medium text-gray-700">
                  Password
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <Lock className="h-5 w-5 text-gray-400" />
                  </div>
                  <input
                    id="password"
                    type="password"
                    value={password}
                    onChange={(e) => {
                      setPassword(e.target.value);
                      setShowNameInput(true);
                    }}
                    className="pl-10 block w-full rounded-md border border-gray-300 shadow-sm py-2 px-3 focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                    placeholder="Enter your password"
                  />
                </div>
              </div>

              <button
                type="submit"
                disabled={isLoading}
                className="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-800 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 transition-colors disabled:opacity-70"
              >
                {isLoading ? 'Signing in...' : 'Sign in'}
              </button>
            </form>
          </div>
        </div>
      </div>

      <footer className="bg-gray-800 text-white text-center py-4 text-sm">
        <p>© 2025 GateSmart+ | Campus Security Solutions</p>
      </footer>
    </div>
  );
};

export default LoginPage;