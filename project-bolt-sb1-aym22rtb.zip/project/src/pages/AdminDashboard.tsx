import React, { useState } from 'react';
import Header from '../components/common/Header';
import { useAuth } from '../contexts/AuthContext';
import { useNotification } from '../contexts/NotificationContext';
import { 
  BarChart3, 
  Users, 
  AlertCircle, 
  Clock, 
  Calendar, 
  ChevronRight,
  CheckCircle2,
  XCircle,
  AlertTriangle 
} from 'lucide-react';
import PendingRequests from '../components/admin/PendingRequests';
import ApprovedRequests from '../components/admin/ApprovedRequests';
import { mockGatePasses, mockStudents } from '../data/mockData';
import AIInsights from '../components/admin/AIInsights';

const AdminDashboard: React.FC = () => {
  const { currentUser } = useAuth();
  const { addNotification } = useNotification();
  const [activeTab, setActiveTab] = useState<'pending' | 'approved' | 'insights'>('pending');
  
  // Get counts for the dashboard
  const pendingCount = mockGatePasses.filter(pass => pass.status === 'pending').length;
  const approvedCount = mockGatePasses.filter(pass => pass.status === 'approved').length;
  const rejectedCount = mockGatePasses.filter(pass => pass.status === 'rejected').length;
  const totalStudents = mockStudents.length;
  
  // Get recent alerts (in a real app, these would come from a database)
  const recentAlerts = [
    { id: '1', type: 'suspicious', message: 'John Doe has requested 5 passes this week', time: '2 hours ago' },
    { id: '2', type: 'emergency', message: 'Emergency alert from Sarah Johnson', time: '1 day ago' },
    { id: '3', type: 'late', message: 'Alex Smith returned 2 hours after curfew', time: '2 days ago' }
  ];

  return (
    <div className="min-h-screen flex flex-col bg-gray-50">
      <Header />
      
      <main className="flex-grow container mx-auto px-4 py-6">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-6">
          <div>
            <h1 className="text-2xl font-bold text-gray-800">Admin Dashboard</h1>
            <p className="text-gray-600">Welcome back, {currentUser?.name}</p>
          </div>
          
          <div className="flex items-center mt-4 md:mt-0">
            <div className="flex items-center text-gray-700 mr-6">
              <Calendar className="h-5 w-5 mr-2 text-blue-800" />
              <span>{new Date().toLocaleDateString()}</span>
            </div>
            <div className="flex items-center text-gray-700">
              <Clock className="h-5 w-5 mr-2 text-blue-800" />
              <span>{new Date().toLocaleTimeString()}</span>
            </div>
          </div>
        </div>
        
        {/* Stats Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
          <div className="bg-white rounded-lg shadow p-4 border-t-4 border-amber-500">
            <div className="flex items-center">
              <div className="flex-shrink-0 bg-amber-100 rounded-md p-3">
                <Clock className="h-6 w-6 text-amber-600" />
              </div>
              <div className="ml-4">
                <h3 className="text-sm font-medium text-gray-500">Pending Requests</h3>
                <span className="text-2xl font-bold text-gray-900">{pendingCount}</span>
              </div>
            </div>
          </div>
          
          <div className="bg-white rounded-lg shadow p-4 border-t-4 border-green-500">
            <div className="flex items-center">
              <div className="flex-shrink-0 bg-green-100 rounded-md p-3">
                <CheckCircle2 className="h-6 w-6 text-green-600" />
              </div>
              <div className="ml-4">
                <h3 className="text-sm font-medium text-gray-500">Approved Passes</h3>
                <span className="text-2xl font-bold text-gray-900">{approvedCount}</span>
              </div>
            </div>
          </div>
          
          <div className="bg-white rounded-lg shadow p-4 border-t-4 border-red-500">
            <div className="flex items-center">
              <div className="flex-shrink-0 bg-red-100 rounded-md p-3">
                <XCircle className="h-6 w-6 text-red-600" />
              </div>
              <div className="ml-4">
                <h3 className="text-sm font-medium text-gray-500">Rejected Passes</h3>
                <span className="text-2xl font-bold text-gray-900">{rejectedCount}</span>
              </div>
            </div>
          </div>
          
          <div className="bg-white rounded-lg shadow p-4 border-t-4 border-blue-500">
            <div className="flex items-center">
              <div className="flex-shrink-0 bg-blue-100 rounded-md p-3">
                <Users className="h-6 w-6 text-blue-600" />
              </div>
              <div className="ml-4">
                <h3 className="text-sm font-medium text-gray-500">Total Students</h3>
                <span className="text-2xl font-bold text-gray-900">{totalStudents}</span>
              </div>
            </div>
          </div>
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-6">
          {/* Recent Alerts */}
          <div className="bg-white rounded-lg shadow overflow-hidden lg:col-span-1">
            <div className="px-4 py-5 sm:px-6 bg-gradient-to-r from-red-600 to-red-700 text-white">
              <h3 className="text-lg font-medium">Recent Alerts</h3>
              <p className="text-sm opacity-80">Security and emergency notifications</p>
            </div>
            <ul className="divide-y divide-gray-200">
              {recentAlerts.map(alert => (
                <li key={alert.id} className="p-4 hover:bg-gray-50">
                  <div className="flex items-start">
                    <div className="flex-shrink-0 pt-0.5">
                      {alert.type === 'emergency' ? (
                        <AlertCircle className="h-5 w-5 text-red-600" />
                      ) : alert.type === 'suspicious' ? (
                        <AlertTriangle className="h-5 w-5 text-amber-600" />
                      ) : (
                        <Clock className="h-5 w-5 text-blue-600" />
                      )}
                    </div>
                    <div className="ml-3 flex-1">
                      <div className="text-sm font-medium text-gray-900">{alert.message}</div>
                      <div className="text-sm text-gray-500">{alert.time}</div>
                    </div>
                    <div className="flex-shrink-0 self-center">
                      <ChevronRight className="h-5 w-5 text-gray-400" />
                    </div>
                  </div>
                </li>
              ))}
            </ul>
            <div className="bg-gray-50 px-4 py-3 text-right">
              <button className="text-sm font-medium text-blue-600 hover:text-blue-800">
                View all alerts
              </button>
            </div>
          </div>
          
          {/* Activity Graph */}
          <div className="bg-white rounded-lg shadow lg:col-span-2">
            <div className="px-4 py-5 sm:px-6 border-b border-gray-200">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-lg font-medium text-gray-900">Weekly Activity</h3>
                  <p className="text-sm text-gray-500">Gate pass requests and usage</p>
                </div>
                <BarChart3 className="h-5 w-5 text-gray-400" />
              </div>
            </div>
            <div className="p-6 flex justify-center items-center">
              {/* This would be a real chart in a production app */}
              <div className="w-full h-60 bg-gray-50 rounded-lg border border-gray-200 flex items-center justify-center">
                <div className="text-center">
                  <BarChart3 className="mx-auto h-8 w-8 text-gray-300" />
                  <p className="mt-2 text-sm text-gray-500">Activity chart visualization would be here</p>
                </div>
              </div>
            </div>
          </div>
        </div>
        
        {/* Tab Navigation */}
        <div className="border-b border-gray-200 mb-6">
          <nav className="flex space-x-8">
            <button
              onClick={() => setActiveTab('pending')}
              className={`py-4 px-1 border-b-2 font-medium text-sm ${
                activeTab === 'pending'
                  ? 'border-blue-800 text-blue-800'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              }`}
            >
              Pending Requests
            </button>
            <button
              onClick={() => setActiveTab('approved')}
              className={`py-4 px-1 border-b-2 font-medium text-sm ${
                activeTab === 'approved'
                  ? 'border-blue-800 text-blue-800'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              }`}
            >
              Approved Passes
            </button>
            <button
              onClick={() => setActiveTab('insights')}
              className={`py-4 px-1 border-b-2 font-medium text-sm ${
                activeTab === 'insights'
                  ? 'border-blue-800 text-blue-800'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              }`}
            >
              AI Insights
            </button>
          </nav>
        </div>
        
        {/* Tab Content */}
        <div className="bg-white rounded-lg shadow-md">
          {activeTab === 'pending' && (
            <PendingRequests />
          )}
          {activeTab === 'approved' && (
            <ApprovedRequests />
          )}
          {activeTab === 'insights' && (
            <AIInsights />
          )}
        </div>
      </main>
      
      <footer className="bg-gray-800 text-white text-center py-4 text-sm">
        <p>© 2025 GateSmart+ | Campus Security Solutions</p>
      </footer>
    </div>
  );
};

export default AdminDashboard;