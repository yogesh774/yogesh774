import React, { useState } from 'react';
import Header from '../components/common/Header';
import { useAuth } from '../contexts/AuthContext';
import { useNotification } from '../contexts/NotificationContext';
import { QrCode, Camera, Users, Clock, UserCheck, AlertTriangle } from 'lucide-react';
import { mockGatePasses, mockStudents } from '../data/mockData';

interface ScannedStudent {
  id: string;
  name: string;
  department?: string;
  image?: string;
  gatePassId: string;
  destination: string;
  expectedReturn: string;
}

const SecurityGate: React.FC = () => {
  const { currentUser } = useAuth();
  const { addNotification } = useNotification();
  const [isScanning, setIsScanning] = useState(false);
  const [scannedStudent, setScannedStudent] = useState<ScannedStudent | null>(null);
  const [showCamera, setShowCamera] = useState(false);
  const [verificationStep, setVerificationStep] = useState<'qr' | 'face' | 'complete'>('qr');
  
  // Recent entries/exits for display
  const [recentActivity, setRecentActivity] = useState([
    { id: '1', studentName: 'Alice Johnson', time: '10:15 AM', type: 'exit' },
    { id: '2', studentName: 'Bob Smith', time: '9:45 AM', type: 'exit' },
    { id: '3', studentName: 'Carol Williams', time: '9:30 AM', type: 'return' }
  ]);

  const startScanning = () => {
    setIsScanning(true);
    setVerificationStep('qr');
    
    // Simulate scanning a QR code
    setTimeout(() => {
      // In a real app, this would be the result of scanning a QR code
      const gatePassId = mockGatePasses.find(pass => pass.status === 'approved')?.id || '';
      const gatePass = mockGatePasses.find(pass => pass.id === gatePassId);
      
      if (gatePass) {
        const student = mockStudents.find(s => s.id === gatePass.studentId);
        
        if (student) {
          setScannedStudent({
            id: student.id,
            name: student.name,
            department: student.department,
            image: student.image,
            gatePassId: gatePass.id,
            destination: gatePass.destination,
            expectedReturn: `${gatePass.expectedReturnDate} ${gatePass.expectedReturnTime}`
          });
          setVerificationStep('face');
        }
      }
    }, 2000);
  };

  const scanFace = () => {
    setShowCamera(true);
    
    // Simulate face scanning
    setTimeout(() => {
      setShowCamera(false);
      setVerificationStep('complete');
    }, 3000);
  };

  const completeVerification = (type: 'exit' | 'return') => {
    if (scannedStudent) {
      // Add to recent activity
      setRecentActivity(prev => [
        { 
          id: Date.now().toString(), 
          studentName: scannedStudent.name, 
          time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }), 
          type 
        },
        ...prev.slice(0, 4) // Keep only the 5 most recent
      ]);
      
      addNotification(`Student ${type === 'exit' ? 'exit' : 'return'} verified successfully`, 'success');
      
      // Reset the scanning state
      setScannedStudent(null);
      setIsScanning(false);
      setVerificationStep('qr');
    }
  };

  const cancelScanning = () => {
    setScannedStudent(null);
    setIsScanning(false);
    setShowCamera(false);
    setVerificationStep('qr');
  };

  return (
    <div className="min-h-screen flex flex-col bg-gray-50">
      <Header />
      
      <main className="flex-grow container mx-auto px-4 py-6">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-6">
          <div>
            <h1 className="text-2xl font-bold text-gray-800">Security Gate Control</h1>
            <p className="text-gray-600">Welcome, {currentUser?.name}</p>
          </div>
          
          <div className="flex items-center mt-4 md:mt-0">
            <div className="text-gray-700">
              <span className="font-medium">{new Date().toLocaleDateString()}</span>
              <span className="mx-2">|</span>
              <span>{new Date().toLocaleTimeString()}</span>
            </div>
          </div>
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Scan Section */}
          <div className="lg:col-span-2">
            <div className="bg-white rounded-lg shadow-md overflow-hidden">
              <div className="px-6 py-4 bg-blue-800 text-white">
                <h2 className="text-xl font-semibold">Gate Pass Scanner</h2>
                <p className="text-blue-100">Scan student QR code and verify identity</p>
              </div>
              
              <div className="p-6">
                {!isScanning ? (
                  <div className="text-center py-12">
                    <QrCode className="mx-auto h-16 w-16 text-blue-400" />
                    <h3 className="mt-4 text-lg font-medium text-gray-900">Ready to Scan</h3>
                    <p className="mt-2 text-gray-500 max-w-md mx-auto">
                      Click the button below to scan a student's gate pass QR code for entry or exit verification.
                    </p>
                    <button
                      onClick={startScanning}
                      className="mt-6 bg-blue-800 hover:bg-blue-700 text-white font-medium py-2 px-6 rounded-md shadow-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 transition-colors"
                    >
                      Start Scanning
                    </button>
                  </div>
                ) : (
                  <div>
                    {/* Step indicator */}
                    <div className="flex items-center justify-center mb-8">
                      <div className="flex items-center">
                        <div className={`flex items-center justify-center w-8 h-8 rounded-full ${
                          verificationStep === 'qr' || verificationStep === 'face' || verificationStep === 'complete' 
                            ? 'bg-blue-600 text-white' 
                            : 'bg-gray-200 text-gray-500'
                        }`}>
                          1
                        </div>
                        <div className="w-12 h-1 bg-gray-200">
                          <div className={`h-full ${
                            verificationStep === 'face' || verificationStep === 'complete' ? 'bg-blue-600' : 'bg-gray-200'
                          }`} />
                        </div>
                        <div className={`flex items-center justify-center w-8 h-8 rounded-full ${
                          verificationStep === 'face' || verificationStep === 'complete'
                            ? 'bg-blue-600 text-white' 
                            : 'bg-gray-200 text-gray-500'
                        }`}>
                          2
                        </div>
                        <div className="w-12 h-1 bg-gray-200">
                          <div className={`h-full ${
                            verificationStep === 'complete' ? 'bg-blue-600' : 'bg-gray-200'
                          }`} />
                        </div>
                        <div className={`flex items-center justify-center w-8 h-8 rounded-full ${
                          verificationStep === 'complete'
                            ? 'bg-blue-600 text-white' 
                            : 'bg-gray-200 text-gray-500'
                        }`}>
                          3
                        </div>
                      </div>
                    </div>
                    
                    {verificationStep === 'qr' && (
                      <div className="text-center py-8">
                        <div className="relative w-64 h-64 mx-auto mb-6 border-2 border-dashed border-blue-300 rounded-lg flex items-center justify-center">
                          <QrCode className="h-12 w-12 text-blue-300" />
                          <div className="absolute inset-0 flex items-center justify-center">
                            <div className="w-full h-0.5 bg-blue-400 animate-scan" />
                          </div>
                        </div>
                        <p className="text-gray-600">Scanning QR code...</p>
                        <button
                          onClick={cancelScanning}
                          className="mt-6 bg-gray-200 hover:bg-gray-300 text-gray-800 font-medium py-2 px-4 rounded-md transition-colors"
                        >
                          Cancel
                        </button>
                      </div>
                    )}
                    
                    {verificationStep === 'face' && scannedStudent && (
                      <div>
                        <div className="flex flex-col md:flex-row items-start gap-6 mb-6">
                          <div className="w-full md:w-auto">
                            <div className="w-32 h-32 rounded-lg bg-blue-100 flex items-center justify-center overflow-hidden">
                              {scannedStudent.image ? (
                                <img src={scannedStudent.image} alt={scannedStudent.name} className="w-full h-full object-cover" />
                              ) : (
                                <Users className="h-16 w-16 text-blue-300" />
                              )}
                            </div>
                          </div>
                          
                          <div className="flex-1">
                            <h3 className="text-xl font-semibold text-gray-900">{scannedStudent.name}</h3>
                            <p className="text-gray-600">{scannedStudent.department}</p>
                            
                            <div className="mt-4 grid grid-cols-1 sm:grid-cols-2 gap-4">
                              <div>
                                <p className="text-sm text-gray-500">Destination</p>
                                <p className="text-gray-900">{scannedStudent.destination}</p>
                              </div>
                              <div>
                                <p className="text-sm text-gray-500">Expected Return</p>
                                <p className="text-gray-900">{scannedStudent.expectedReturn}</p>
                              </div>
                            </div>
                          </div>
                        </div>
                        
                        {showCamera ? (
                          <div className="relative w-full h-64 bg-gray-100 rounded-lg mb-6 flex items-center justify-center">
                            <Camera className="h-12 w-12 text-gray-400" />
                            <div className="absolute inset-0 border-2 border-blue-400 rounded-lg">
                              <div className="absolute top-1/2 left-0 w-full h-0.5 bg-blue-500 animate-scan"></div>
                            </div>
                            <p className="text-gray-600 absolute bottom-4">Scanning face...</p>
                          </div>
                        ) : (
                          <div className="mb-6">
                            <button
                              onClick={scanFace}
                              className="w-full bg-blue-800 hover:bg-blue-700 text-white font-medium py-3 px-4 rounded-md shadow-md transition-colors flex items-center justify-center"
                            >
                              <Camera className="h-5 w-5 mr-2" />
                              Scan Face to Verify
                            </button>
                          </div>
                        )}
                        
                        <div className="flex justify-end">
                          <button
                            onClick={cancelScanning}
                            className="bg-gray-200 hover:bg-gray-300 text-gray-800 font-medium py-2 px-4 rounded-md mr-2 transition-colors"
                          >
                            Cancel
                          </button>
                        </div>
                      </div>
                    )}
                    
                    {verificationStep === 'complete' && scannedStudent && (
                      <div>
                        <div className="flex items-center justify-center mb-6">
                          <div className="w-16 h-16 rounded-full bg-green-100 flex items-center justify-center">
                            <UserCheck className="h-8 w-8 text-green-600" />
                          </div>
                        </div>
                        
                        <h3 className="text-xl font-semibold text-center text-gray-900 mb-2">Verification Complete</h3>
                        <p className="text-center text-gray-600 mb-6">Student identity confirmed</p>
                        
                        <div className="p-4 bg-blue-50 rounded-lg border border-blue-200 mb-6">
                          <div className="flex flex-col md:flex-row items-start gap-4">
                            <div className="w-16 h-16 rounded-lg bg-blue-100 flex items-center justify-center overflow-hidden">
                              {scannedStudent.image ? (
                                <img src={scannedStudent.image} alt={scannedStudent.name} className="w-full h-full object-cover" />
                              ) : (
                                <Users className="h-8 w-8 text-blue-300" />
                              )}
                            </div>
                            
                            <div>
                              <h4 className="text-lg font-medium text-gray-900">{scannedStudent.name}</h4>
                              <p className="text-gray-600">{scannedStudent.department}</p>
                              <p className="text-gray-600 mt-1">Destination: {scannedStudent.destination}</p>
                            </div>
                          </div>
                        </div>
                        
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-6">
                          <button
                            onClick={() => completeVerification('exit')}
                            className="bg-blue-800 hover:bg-blue-700 text-white font-medium py-3 px-4 rounded-md shadow-md transition-colors"
                          >
                            Record Exit
                          </button>
                          <button
                            onClick={() => completeVerification('return')}
                            className="bg-green-600 hover:bg-green-700 text-white font-medium py-3 px-4 rounded-md shadow-md transition-colors"
                          >
                            Record Return
                          </button>
                        </div>
                        
                        <div className="flex justify-end">
                          <button
                            onClick={cancelScanning}
                            className="bg-gray-200 hover:bg-gray-300 text-gray-800 font-medium py-2 px-4 rounded-md transition-colors"
                          >
                            Cancel
                          </button>
                        </div>
                      </div>
                    )}
                  </div>
                )}
              </div>
            </div>
          </div>
          
          {/* Recent Activity */}
          <div>
            <div className="bg-white rounded-lg shadow-md overflow-hidden">
              <div className="px-6 py-4 bg-gray-800 text-white">
                <h2 className="text-xl font-semibold">Recent Activity</h2>
                <p className="text-gray-300">Latest entries and exits</p>
              </div>
              
              <div className="divide-y divide-gray-200">
                {recentActivity.map((activity, index) => (
                  <div key={activity.id} className="p-4 hover:bg-gray-50">
                    <div className="flex items-start">
                      <div className={`flex-shrink-0 w-10 h-10 rounded-full flex items-center justify-center ${
                        activity.type === 'exit' ? 'bg-blue-100' : 'bg-green-100'
                      }`}>
                        {activity.type === 'exit' ? (
                          <Clock className={`h-5 w-5 text-blue-600`} />
                        ) : (
                          <UserCheck className={`h-5 w-5 text-green-600`} />
                        )}
                      </div>
                      <div className="ml-3 flex-1">
                        <p className="text-sm font-medium text-gray-900">{activity.studentName}</p>
                        <div className="flex items-center mt-1">
                          <span className={`text-xs font-medium px-2 py-0.5 rounded-full ${
                            activity.type === 'exit' 
                              ? 'bg-blue-100 text-blue-800' 
                              : 'bg-green-100 text-green-800'
                          }`}>
                            {activity.type === 'exit' ? 'Exit' : 'Return'}
                          </span>
                          <span className="text-xs text-gray-500 ml-2">{activity.time}</span>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
                
                {recentActivity.length === 0 && (
                  <div className="p-6 text-center">
                    <Clock className="mx-auto h-8 w-8 text-gray-300" />
                    <p className="mt-2 text-sm text-gray-500">No recent activity</p>
                  </div>
                )}
              </div>
            </div>
            
            <div className="mt-6 bg-amber-50 border-l-4 border-amber-500 p-4 rounded-md">
              <div className="flex">
                <div className="flex-shrink-0">
                  <AlertTriangle className="h-5 w-5 text-amber-500" />
                </div>
                <div className="ml-3">
                  <h3 className="text-sm font-medium text-amber-800">Important Reminder</h3>
                  <p className="text-sm text-amber-700 mt-1">
                    Always verify student identity with both QR code and face recognition. 
                    Report any suspicious behavior to administration immediately.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>
      
      <footer className="bg-gray-800 text-white text-center py-4 text-sm">
        <p>© 2025 GateSmart+ | Campus Security Solutions</p>
      </footer>
      
      {/* Add animations for scanning effect */}
      <style jsx="true">{`
        @keyframes scan {
          0% { transform: translateY(0); }
          50% { transform: translateY(100%); }
          100% { transform: translateY(0); }
        }
        .animate-scan {
          animation: scan 2s linear infinite;
        }
      `}</style>
    </div>
  );
};

export default SecurityGate;