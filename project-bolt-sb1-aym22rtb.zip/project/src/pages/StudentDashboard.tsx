import React, { useState } from 'react';
import Header from '../components/common/Header';
import { useAuth } from '../contexts/AuthContext';
import { useNotification } from '../contexts/NotificationContext';
import GatePassForm from '../components/student/GatePassForm';
import GatePassHistory from '../components/student/GatePassHistory';
import { Calendar, Clock, AlertTriangle } from 'lucide-react';
import { mockGatePasses } from '../data/mockData';

const StudentDashboard: React.FC = () => {
  const { currentUser } = useAuth();
  const { addNotification } = useNotification();
  const [activeTab, setActiveTab] = useState<'apply' | 'history'>('apply');

  // Filter gate passes for current student
  const studentPasses = mockGatePasses.filter(pass => 
    pass.studentId === currentUser?.id
  );

  const pendingPasses = studentPasses.filter(pass => 
    pass.status === 'pending'
  );

  const handleEmergency = () => {
    addNotification('Emergency alert sent to administration!', 'warning');
    // In a real app, this would send an API request to notify administrators
  };

  return (
    <div className="min-h-screen flex flex-col bg-gray-50">
      <Header />
      
      <main className="flex-grow container mx-auto px-4 py-6">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-6">
          <div>
            <h1 className="text-2xl font-bold text-gray-800">Student Dashboard</h1>
            <p className="text-gray-600">Welcome back, {currentUser?.name}</p>
          </div>
          
          <button 
            onClick={handleEmergency}
            className="mt-4 md:mt-0 bg-red-600 hover:bg-red-700 text-white px-4 py-2 rounded-md flex items-center justify-center shadow-md transition-colors"
          >
            <AlertTriangle className="mr-2 h-5 w-5" />
            Emergency Alert
          </button>
        </div>
        
        {/* Student Info Card */}
        <div className="bg-white rounded-lg shadow-md p-6 mb-6">
          <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4">
            <div className="w-16 h-16 rounded-full bg-blue-100 flex items-center justify-center overflow-hidden">
              {currentUser?.image ? (
                <img src={currentUser.image} alt={currentUser.name} className="w-full h-full object-cover" />
              ) : (
                <span className="text-blue-800 text-xl font-bold">{currentUser?.name.charAt(0)}</span>
              )}
            </div>
            <div>
              <h2 className="text-xl font-semibold text-gray-800">{currentUser?.name}</h2>
              <p className="text-gray-600">Student ID: {currentUser?.studentId}</p>
              <p className="text-gray-600">Department: {currentUser?.department}</p>
            </div>
            
            <div className="sm:ml-auto flex flex-col sm:items-end mt-4 sm:mt-0">
              <div className="flex items-center text-gray-700 mb-2">
                <Calendar className="h-5 w-5 mr-2 text-blue-600" />
                <span>{new Date().toLocaleDateString()}</span>
              </div>
              <div className="flex items-center text-gray-700">
                <Clock className="h-5 w-5 mr-2 text-blue-600" />
                <span>{new Date().toLocaleTimeString()}</span>
              </div>
            </div>
          </div>
        </div>
        
        {/* Stats Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
          <div className="bg-blue-50 border-l-4 border-blue-500 rounded-lg shadow p-4">
            <h3 className="text-lg font-medium text-blue-800">Total Passes</h3>
            <p className="text-3xl font-bold text-blue-900">{studentPasses.length}</p>
          </div>
          
          <div className="bg-amber-50 border-l-4 border-amber-500 rounded-lg shadow p-4">
            <h3 className="text-lg font-medium text-amber-800">Pending</h3>
            <p className="text-3xl font-bold text-amber-900">{pendingPasses.length}</p>
          </div>
          
          <div className="bg-green-50 border-l-4 border-green-500 rounded-lg shadow p-4">
            <h3 className="text-lg font-medium text-green-800">Approved</h3>
            <p className="text-3xl font-bold text-green-900">
              {studentPasses.filter(pass => pass.status === 'approved').length}
            </p>
          </div>
          
          <div className="bg-red-50 border-l-4 border-red-500 rounded-lg shadow p-4">
            <h3 className="text-lg font-medium text-red-800">Rejected</h3>
            <p className="text-3xl font-bold text-red-900">
              {studentPasses.filter(pass => pass.status === 'rejected').length}
            </p>
          </div>
        </div>
        
        {/* Tab Navigation */}
        <div className="border-b border-gray-200 mb-6">
          <nav className="flex space-x-8">
            <button
              onClick={() => setActiveTab('apply')}
              className={`py-4 px-1 border-b-2 font-medium text-sm ${
                activeTab === 'apply'
                  ? 'border-blue-800 text-blue-800'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              }`}
            >
              Apply for Gate Pass
            </button>
            <button
              onClick={() => setActiveTab('history')}
              className={`py-4 px-1 border-b-2 font-medium text-sm ${
                activeTab === 'history'
                  ? 'border-blue-800 text-blue-800'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              }`}
            >
              Pass History
            </button>
          </nav>
        </div>
        
        {/* Tab Content */}
        <div className="bg-white rounded-lg shadow-md p-6">
          {activeTab === 'apply' ? (
            <GatePassForm />
          ) : (
            <GatePassHistory gatePasses={studentPasses} />
          )}
        </div>
      </main>
      
      <footer className="bg-gray-800 text-white text-center py-4 text-sm">
        <p>© 2025 GateSmart+ | Campus Security Solutions</p>
      </footer>
    </div>
  );
};

export default StudentDashboard;