// Mock data for the GateSmart+ application

// Mock users for authentication
export const mockUsers = [
  {
    id: '1',
    name: '',
    email: 'student@example.com',
    role: 'student',
    studentId: 'S12345',
    department: 'Computer Science',
    image: 'https://images.pexels.com/photos/2379005/pexels-photo-2379005.jpeg?auto=compress&cs=tinysrgb&w=400'
  },
  {
    id: '2',
    name: '',
    email: 'admin@example.com',
    role: 'admin',
    image: 'https://images.pexels.com/photos/3785104/pexels-photo-3785104.jpeg?auto=compress&cs=tinysrgb&w=400'
  },
  {
    id: '3',
    name: '',
    email: 'security@example.com',
    role: 'security',
    image: 'https://images.pexels.com/photos/8961065/pexels-photo-8961065.jpeg?auto=compress&cs=tinysrgb&w=400'
  }
];

// Mock students
export const mockStudents = [
  {
    id: '1',
    name: '',
    email: 'student@example.com',
    studentId: 'S12345',
    department: 'Computer Science',
    image: 'https://images.pexels.com/photos/2379005/pexels-photo-2379005.jpeg?auto=compress&cs=tinysrgb&w=400'
  }
];

// Mock gate passes
export const mockGatePasses = [
  {
    id: 'gp-001',
    studentId: '1',
    reason: 'Medical appointment at City Hospital',
    destination: 'City Hospital',
    leaveDate: '2025-05-15',
    leaveTime: '09:00',
    expectedReturnDate: '2025-05-15',
    expectedReturnTime: '13:00',
    status: 'approved',
    actualExitTime: '09:05',
    actualReturnTime: '12:45'
  }
];