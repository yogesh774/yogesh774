/*
  # Initial Schema Setup for GateSmart+

  1. New Tables
    - `users` - Stores user profiles and authentication data
      - `id` (uuid, primary key) - User's unique identifier
      - `email` (text) - User's email address
      - `name` (text) - User's full name
      - `role` (text) - User's role (student, admin, security)
      - `department` (text, nullable) - Department for students
      - `student_id` (text, nullable) - Student ID for students
      - `created_at` (timestamptz) - Account creation timestamp

    - `gate_passes` - Stores gate pass requests
      - `id` (uuid, primary key) - Gate pass unique identifier
      - `user_id` (uuid) - Reference to the user who created the pass
      - `reason` (text) - Reason for the gate pass
      - `destination` (text) - Where the student is going
      - `leave_date` (date) - Date of departure
      - `leave_time` (time) - Time of departure
      - `expected_return_date` (date) - Expected return date
      - `expected_return_time` (time) - Expected return time
      - `status` (text) - Current status (pending, approved, rejected)
      - `actual_exit_time` (timestamptz) - When the student actually left
      - `actual_return_time` (timestamptz) - When the student actually returned
      - `contact_number` (text) - Emergency contact number
      - `accompanied_by` (text) - Who is accompanying the student
      - `created_at` (timestamptz) - When the pass was requested
      - `updated_at` (timestamptz) - Last update timestamp

  2. Security
    - Enable RLS on all tables
    - Add policies for data access based on user roles
*/

-- Create users table
CREATE TABLE users (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  email text UNIQUE NOT NULL,
  name text NOT NULL,
  role text NOT NULL CHECK (role IN ('student', 'admin', 'security')),
  department text,
  student_id text,
  created_at timestamptz DEFAULT now(),
  CONSTRAINT valid_student_info CHECK (
    (role = 'student' AND department IS NOT NULL AND student_id IS NOT NULL) OR
    (role != 'student' AND department IS NULL AND student_id IS NULL)
  )
);

-- Create gate passes table
CREATE TABLE gate_passes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES users(id) NOT NULL,
  reason text NOT NULL,
  destination text NOT NULL,
  leave_date date NOT NULL,
  leave_time time NOT NULL,
  expected_return_date date NOT NULL,
  expected_return_time time NOT NULL,
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'approved', 'rejected')),
  actual_exit_time timestamptz,
  actual_return_time timestamptz,
  contact_number text,
  accompanied_by text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  CONSTRAINT valid_return_time CHECK (expected_return_date >= leave_date)
);

-- Enable Row Level Security
ALTER TABLE users ENABLE ROW LEVEL SECURITY;
ALTER TABLE gate_passes ENABLE ROW LEVEL SECURITY;

-- Users table policies
CREATE POLICY "Users can read their own data"
  ON users
  FOR SELECT
  TO authenticated
  USING (auth.uid() = id);

CREATE POLICY "Admins can read all users"
  ON users
  FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM users
      WHERE users.id = auth.uid()
      AND users.role = 'admin'
    )
  );

-- Gate passes policies
CREATE POLICY "Students can create their own passes"
  ON gate_passes
  FOR INSERT
  TO authenticated
  WITH CHECK (
    auth.uid() = user_id AND
    EXISTS (
      SELECT 1 FROM users
      WHERE users.id = auth.uid()
      AND users.role = 'student'
    )
  );

CREATE POLICY "Students can read their own passes"
  ON gate_passes
  FOR SELECT
  TO authenticated
  USING (
    user_id = auth.uid() OR
    EXISTS (
      SELECT 1 FROM users
      WHERE users.id = auth.uid()
      AND (users.role = 'admin' OR users.role = 'security')
    )
  );

CREATE POLICY "Admins can update any pass"
  ON gate_passes
  FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM users
      WHERE users.id = auth.uid()
      AND users.role = 'admin'
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM users
      WHERE users.id = auth.uid()
      AND users.role = 'admin'
    )
  );

CREATE POLICY "Security can update exit and return times"
  ON gate_passes
  FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM users
      WHERE users.id = auth.uid()
      AND users.role = 'security'
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM users
      WHERE users.id = auth.uid()
      AND users.role = 'security'
    ) AND
    (
      (OLD.actual_exit_time IS NULL AND NEW.actual_exit_time IS NOT NULL AND NEW.actual_return_time IS NULL) OR
      (OLD.actual_return_time IS NULL AND NEW.actual_return_time IS NOT NULL)
    )
  );

-- Create function to update updated_at timestamp
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ language 'plpgsql';

-- Create trigger for updated_at
CREATE TRIGGER update_gate_passes_updated_at
  BEFORE UPDATE ON gate_passes
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();